<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoProgress extends Model
{
    //video_progress
}
