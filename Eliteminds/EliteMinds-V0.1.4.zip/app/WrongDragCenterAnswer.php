<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WrongDragCenterAnswer extends Model
{
    //
}
