<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ZoneCountry extends Model
{
    //
}
