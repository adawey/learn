<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthSocialController extends Controller
{
    //
}
