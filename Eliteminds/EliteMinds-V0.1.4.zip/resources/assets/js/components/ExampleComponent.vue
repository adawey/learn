<template>
    hello world;
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
