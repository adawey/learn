<center>Use Computer For Windows. For Application "Android", search for {{env('APP_NAME')}} in the Play Store.</center>
<a href="{{route('user.dashboard')}}"> Click Here To Go Dashboard </a>
