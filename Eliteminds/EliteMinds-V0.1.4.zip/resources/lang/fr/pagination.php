<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Lignes de langue de pagination
    |--------------------------------------------------------------------------
    |
    | Les lignes de langage suivantes sont utilisées par la bibliothèque paginator pour consolider.
    | les liens de pagination simples. Vous êtes libre de les changer à quoi que ce soit.
    | you want to customize your views to better match your application.
    |
    */

    'previous' => '&laquo; Précédent',
    'next' => 'Suivant &raquo;',

];
