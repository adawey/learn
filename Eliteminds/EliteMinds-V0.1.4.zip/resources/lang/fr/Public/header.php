<?php

return [
    'home'              => 'Accueil',
    'about-us'          => 'Qui somme nous',
    'all-courses'       => 'Tous les cours',
    'my-courses'        => 'Mes cours',
    'my-dashboard'      => 'Mon tableau de bord',
    'dashboard'         => 'Tableau de bord',
    'login'             => 'Se connecter',
    'sign-up'           => 'S\'inscrire',
    'logout'            => 'Se déconnecter',

];
