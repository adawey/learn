<?php

return [
    'my-courses'            => 'دوراتي',
    'exams'                 => 'الاختبارات',
    'all'                   => 'الكل',
    'expire-at'             => 'تنتهي في',
    'exam'                  => 'أسئلة',
    'questions'             => 'سؤال',
    'videos'                => 'فيديوهات',
    'lectures'              => 'محاضرة',
    'hours'                 => 'ساعة',
    'online-sessions'       => 'دورات تفاعليةأونلاين',
    'end-at'                => 'ينتهي في',
    'time-table'            => ' جدول المحاضرات',
    'date'                  => 'التاريخ',
    'from'                  => 'من',
    'to'                    => 'الي',
    'close'                 => 'أغلق',
    'view-event'            => 'عرض المحتوى',
    'not-available'         => 'ليس متاح الأن.',
    'expired-courses'       => 'الدورات منتهية الصلاحية',
    'reset'                 => 'إعادة تعيين',
    'extend'                => 'تمديد',
    'No expired courses'   => ' لا يوجد دورات منتهية!',
    

];
