<?php

return [
    'home'              => 'الرئيسية',
    'about-us'          => 'من نحن',
    'all-courses'       => 'جميع الدورات',
    'my-courses'        => 'دوراتي',
    'my-dashboard'      => 'لوحة التحكم',
    'dashboard'         => 'لوحة التحكم',
    'login'             => 'تسجيل الدخول',
    'sign-up'           => 'إنشاء حساب',
    'logout'            => 'تسجيل خروج',

];
