<?php

return [
    'my-courses'            => 'My Courses',
    'exams'                 => 'Exams',
    'all'                   => 'All',
    'expire-at'             => 'Expire at',
    'exam'                  => 'Exam',
    'questions'             => 'Questions',
    'videos'                => 'Videos',
    'lectures'              => 'Lectures',
    'hours'                 => 'Hours',
    'online-sessions'       => 'Online Interactive Sessions',
    'end-at'                => 'Ends at',
    'time-table'            => 'Time Table',
    'date'                  => 'Date',
    'from'                  => 'From',
    'to'                    => 'To',
    'close'                 => 'Close',
    'view-event'            => 'View Event',
    'not-available'         => 'Not Available now.',
    'expired-courses'       => 'Expired Courses',
    'reset'                 => 'Reset',
    'extend'                => 'Extend',
    'packages-are-active'   => 'No Package is Expired.',

 ];
