<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackageExtension extends Model
{
    //
}
