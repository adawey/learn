<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FlashCard extends Model
{
    //
}
