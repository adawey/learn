<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CorrectDragRightAnswer extends Model
{
    //
}
