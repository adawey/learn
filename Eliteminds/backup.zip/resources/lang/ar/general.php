<?php

return [
    'language'  => 'اللغة',
    'kill-mistakes' => 'الاخطاء',
    'no-translation'    => 'لا توجد ترجمة',
];
