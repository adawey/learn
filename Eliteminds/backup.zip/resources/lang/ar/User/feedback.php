<?php

return [
    'feedback'          => ' تقييم الدورات',
    'rating'            => 'تقييم',
    '5stars'            => '5 نجوم',
    '4stars'            => '4 نجوم',
    '3stars'            => '3 نجوم',
    '2stars'            => '2 نجوم',
    '1stars'            => '1 نجوم',
    'title'             => 'عنوان',
    'send'              => 'إرسال',
    'delete'            => 'حذف',
];

