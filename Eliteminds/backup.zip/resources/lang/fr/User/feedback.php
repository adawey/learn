<?php

return [
    'feedback'          => 'Retour',
    'rating'            => 'Évaluation',
    '5stars'            => '5 Étoiles',
    '4stars'            => '4 Étoiles',
    '3stars'            => '3 Étoiles',
    '2stars'            => '2 Étoiles',
    '1stars'            => '1 Étoiles',
    'title'             => 'Titre',
    'send'              => 'Envoyer',
    'delete'            => 'Effacer',
];

