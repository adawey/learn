<?php

return [
    'welcome'               => 'Bienvenue aux '.env('APP_NAME').' Aide Communauté',
    'search-something'      => 'Rechercher quelque chose ... ',
    'faq'                   => 'QF',
    'submit-review'         => 'Soumettre un avis ',
    'comment'               => 'Commenter',
    'submit'                => 'Soumettre',
    'comment-here'          => 'Entrez vos commentaires ici..',
    'reply'                 => 'Repondre',
];
