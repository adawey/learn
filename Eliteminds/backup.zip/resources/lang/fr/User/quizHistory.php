<?php

return [
    'chapters-mistakes'             => 'Les Erreurs des chapitres',
    'processes-mistakes'            => 'Les Erreurs des Domaines',
    'exam-mistakes'                 => 'Les Erreurs des Examens',
    'exam'                          => 'Examen',
    'success'                       => 'Succès',
    'failed'                        => 'Echec',
    'correct'                       => 'Correcte',
    'hour'                          => 'Heur',
    'min'                           => 'Min',
    'sec'                           => 'Sec',
    'review'                        => 'Revoir',
    'note'                          => 'Notez que : tous les résultats des tests pratiqués sont conservés afin de vous permettre d\'examiner vos progrès.',

];
