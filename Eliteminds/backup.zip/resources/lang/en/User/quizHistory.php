<?php

return [
    'chapters-mistakes'             => 'Chapters Mistakes',
    'processes-mistakes'            => 'Domains Mistakes',
    'exam-mistakes'                 => 'Exams Mistakes',
    'exam'                          => 'Exam',
    'success'                       => 'Success',
    'failed'                        => 'Failed',
    'correct'                       => 'Correct',
    'hour'                          => 'Hour',
    'min'                           => 'Min',
    'sec'                           => 'Sec',
    'review'                        => 'Review',
    'note'                          => 'Notice That: All Practice tests result are kept for you to reivew you progress.',

];
