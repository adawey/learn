<?php

return [
    'language'          => 'Language',
    'kill-mistakes'     => 'Kill Mistakes',
    'no-translation'    => 'No Translation Found !',
];
