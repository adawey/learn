Name: {{$data[0]}} <br>
Email:  {{$data[1]}} <br>
<br>
Message: <br>
{{$data[2]}}
